export const SHOP_DATA = {
    items: [{
        id: 1,
        type: 1,
        name: 'Test Book 1',
        vedioUrl: '',
        imageUrl: "../assets/img/hero-1.jpg",
        price: 25,
        description: "It's been nearly 25 years since Robert Kiyosaki’s Rich Dad Poor Dad first made waves in the Personal Finance arena. It has since become the #1 Personal Finance book of all time... translated into dozens of languages and sold around the world. Rich Dad Poor Dad is Robert's story of growing up with two dads — his real father and the father of his best friend, his rich dad — and the ways in which both men shaped his thoughts about money and investing. The book explodes the myth that you need to earn a high income to be rich and explains the difference between working for money and having your money work for you.",
        originalPrice: 40
    },
    {
        id: 2,
        type: 1,
        name: 'Test Book 2',
        vedioUrl: '',
        imageUrl: "../assets/img/hero-2.jpg",
        price: 55,
        description: "It's been nearly 25 years since Robert Kiyosaki’s Rich Dad Poor Dad first made waves in the Personal Finance arena. It has since become the #1 Personal Finance book of all time... translated into dozens of languages and sold around the world. Rich Dad Poor Dad is Robert's story of growing up with two dads — his real father and the father of his best friend, his rich dad — and the ways in which both men shaped his thoughts about money and investing. The book explodes the myth that you need to earn a high income to be rich and explains the difference between working for money and having your money work for you.",
        originalPrice: 80
    },
    {
        id: 3,
        type: 1,
        name: 'Test Book 3',
        vedioUrl: '',
        imageUrl: "../assets/img/hero-1.jpg",
        price: 35,
        description: "It's been nearly 25 years since Robert Kiyosaki’s Rich Dad Poor Dad first made waves in the Personal Finance arena. It has since become the #1 Personal Finance book of all time... translated into dozens of languages and sold around the world. Rich Dad Poor Dad is Robert's story of growing up with two dads — his real father and the father of his best friend, his rich dad — and the ways in which both men shaped his thoughts about money and investing. The book explodes the myth that you need to earn a high income to be rich and explains the difference between working for money and having your money work for you.",
        originalPrice: 90
    },
    {
        id: 4,
        type: 2,
        name: 'Test Vedio Clip',
        vedioUrl: 'https://www.youtube.com/embed/tgbNymZ7vqY',
        imageUrl: "../assets/img/hero-1.jpg",
        price: 40,
        description: "It's been nearly 25 years since Robert Kiyosaki’s Rich Dad Poor Dad first made waves in the Personal Finance arena. It has since become the #1 Personal Finance book of all time... translated into dozens of languages and sold around the world. Rich Dad Poor Dad is Robert's story of growing up with two dads — his real father and the father of his best friend, his rich dad — and the ways in which both men shaped his thoughts about money and investing. The book explodes the myth that you need to earn a high income to be rich and explains the difference between working for money and having your money work for you.",
        originalPrice: 80
    }]
};