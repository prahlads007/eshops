const host = "https://localhost:7147"
export const URL = {
    product: host + "/api/Product",
    cart: host + "/api/Cart",
    order: host + "/api/Order"
}