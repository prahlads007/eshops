import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import List from "./pages/List";
import Membership from "./pages/Membership";
import Contact from "./pages/Contact";
import Layout from "./pages/Layout";
import ProductDetails from "./components/Product/ProductDetails"
import reportWebVitals from './reportWebVitals';
import Checkout from './components/Checkout/Checkout';
import Orders from './pages/Orders';


export default function App() {
  return (
    <BrowserRouter>
      <Routes>
          <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="list" element={<List />} />
          <Route path="contact" element={<Contact />} />
          <Route path="membership" element={<Membership />} />
          <Route path="orders" element={<Orders />} />
          <Route path="product/:id" element={<ProductDetails />} />
          <Route path="checkout/:id" element={<Checkout />} />
          <Route path="*" element={<Home />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);