import React, { useEffect, useState } from "react";
import { URL } from "../../utils/AppConstant";
import {
    BrowserRouter as Router,
    Link,
    useParams,
} from "react-router-dom";
import './ProductDetails.css';
import Layout from "../../pages/Layout"

function ProductDetails(props) {
    const { id } = useParams();
    const [ProductDetails, setProductDetails] = useState(null)
    useEffect(() => {
        id && getProductList();
    }, [])
    const getProductList = async () => {
        try {
            const response = await fetch(URL.product);
            const data = await response.json();
            setProductDetails(data.result.products.filter(x => x.id == id)[0]);
        } catch (e) {
            console.log(e);
        }
    }

    return (ProductDetails &&


        <div>
            <section class="man-banner spad">
                <div class="container-fluid">
                    <div class="row">
                        <div key={ProductDetails.id} class="col-md-12">
                            <div class="productDetails">
                                <div class="product-item">
                                    <div class="pi-pic">
                                        {ProductDisplay(ProductDetails.type, ProductDetails.type === 2 ? ProductDetails.vedioUrl : ProductDetails.imageUrl)}

                                        <div class="icon">
                                            <i class="icon_heart_alt"></i>
                                        </div>
                                    </div>
                                    <div class="pi-text">
                                        <div class="catagory-name">Type: {ProductDetails.type === 2 ? 'Vedio' : 'Book'} </div>

                                        <div class="product-price">
                                            ${ProductDetails.price}
                                            <span>${ProductDetails.originalPrice}</span>
                                        </div>
                                    </div>
                                </div></div>
                            <div class="productDescription" >
                                <h3>{ProductDetails.name}</h3>
                                <br />
                                <p>{ProductDetails.description}</p>
                                <br />
                                <div class="action">
                                    <Link class="add-to-cart btn btn-default" to={`/checkout/${ProductDetails.id}`} >add to cart</Link>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
        </div>
    );
};

function ProductDisplay(type, url) {
    if (type === 2) {

        return <iframe width="420" height="315"
            src={url}>
        </iframe>
    } else {

        return <img src={`${url}`} alt="" />
    }
}

export default ProductDetails;