import React, { useEffect, useState } from "react";
import { URL } from "../../utils/AppConstant";
import randomNumber from "../../libs/Common"
import {
  BrowserRouter as Router,
  useParams,
} from "react-router-dom";
import './Checkout.css';
import '../Shared/font-awesom.css'
import Layout from "../../pages/Layout"
import Toast from "../../libs/toast/Toast"

function Checkout() {
  const { id } = useParams();
  const [CartDetails, setCartDetails] = useState(null);
  const [TotalPrice, setTotalPrice] = useState(0);
  const [ProductCount, setProductCount] = useState(0);
  const [billAddress, setBillAddress] = useState('21-A, Mayur vihar phase 3');
  useEffect(() => {
    AddToCart();
  }, [])
  useEffect(() => {
    CartDetails && CartItems()
  }, [CartDetails]);
  const handleAddressChange = event => {
    setBillAddress(event.target.value);
  };
  const orderHandler = async () => {
    try {
      const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          "id": randomNumber(),
          sku: id,
          amount: TotalPrice,
          productName: "Temprory name...",
          username: "Abhishek",
          billAddress: billAddress,
          shipAddress: billAddress,
          status: "Order Confirmed",
          paymentStatus: "Success"
        })
      };
      await fetch(URL.order, requestOptions);
      window.location.href = window.location.origin;
    } catch (e) {
      console.log(e);
    }
    alert('Order Placed successfully!');
  }
  // const testList = [
  //   {
  //     id: 1,
  //     title: 'Success',
  //     description: 'This is a success toast component',
  //     backgroundColor: '#5cb85c'
  //   },
  //   {
  //     id: 2,
  //     title: 'Danger',
  //     description: 'This is an error toast component',
  //     backgroundColor: '#d9534f'
  //   },];
  const getCartList = async () => {
    try {
      const response = await fetch(URL.cart);
      const data = await response.json();
      setCartDetails(data.result.addedItems);
    } catch (e) {
      console.log(e);
    }
  }

  const AddToCart = async () => {
    try {
      const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
      };
      const addCartList = await fetch(URL.cart, requestOptions);
      await getCartList();
    } catch (e) {
      console.log(e);
    }
  }

  function CartItems() {
    let total = 0;
    let cartCount = 0;
    let cartProducts;
    CartDetails.forEach(item => {
      total = total + (item.quantity * item.price);
      cartCount++;

    });
    setTotalPrice(total);
    setProductCount(cartCount);
  }

  return (CartDetails && BullingDetails()
  );


  function BullingDetails() {
    return <div>
      {/* <Toast toastList={testList} position="top-right" /> */}
      <div class="checkoutRow">
        <div class="checkoutCol-75">
          <div class="checkoutContainer">
            <div class="checkoutRow">
              <div class="checkoutCol-50">
                <h3>Billing Address</h3>
                <label for="fname"><i class="fa fa-user"></i> Full Name</label>
                <input type="text" id="fname" name="firstname" value="Abhishek Kumar" />
                <label for="email"><i class="fa fa-envelope"></i> Email</label>
                <input type="text" id="email" name="email" value="abhishek@abc.com" />
                <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
                <input type="text" id="billAddress" name="billAddress" onChange={handleAddressChange} value="21-A, Mayur vihar phase 3" />
                <label for="city"><i class="fa fa-institution"></i> City</label>
                <input type="text" id="city" name="city" value="Delhi" />

                <div class="checkoutRow">
                  <div class="checkoutCol-50">
                    <label for="state">State</label>
                    <input type="text" id="state" name="state" value="Delhi" />
                  </div>
                  <div class="checkoutCol-50">
                    <label for="zip">Zip</label>
                    <input type="text" id="zip" name="zip" value="110096" />
                  </div>
                </div>
              </div>

              <div class="checkoutCol-50">
                <h3>Payment</h3>
                <label for="fname">Accepted Cards</label>
                <div class="icon-checkoutContainer">
                  <i class="fa fa-cc-visa" style={{ color: "navy" }}></i>
                  <i class="fa fa-cc-amex" style={{ color: "blue" }}></i>
                  <i class="fa fa-cc-mastercard" style={{ color: "red" }}></i>
                  <i class="fa fa-cc-discover" style={{ color: "orange" }}></i>
                </div>
                <label for="cname">Name on Card</label>
                <input type="text" id="cname" name="cardname" />
                <label for="ccnum">Credit card number</label>
                <input type="text" id="ccnum" name="cardnumber"  />
                <label for="expmonth">Exp Month</label>
                <input type="text" id="expmonth" name="expmonth" />
                <div class="checkoutRow">
                  <div class="checkoutCol-50">
                    <label for="expyear">Exp Year</label>
                    <input type="text" id="expyear" name="expyear"  />
                  </div>
                  <div class="checkoutCol-50">
                    <label for="cvv">CVV</label>
                    <input type="text" id="cvv" name="cvv"  />
                  </div>
                </div>
              </div>

            </div>
            <label>
              <input type="checkbox" checked="checked" name="sameadr" /> Shipping address same as billing
            </label>
            <input type="submit" onClick={orderHandler} value="Confirm & Submit" class="btn" />
          </div>
        </div>
        <div class="checkoutCol-25">
          <div class="checkoutContainer">
            <h4>Cart <span class="CheckoutPrice" style={{ color: "black" }}><i class="fa fa-shopping-cart"></i> <b>{ProductCount}</b></span></h4>
            {CartDetails.map(item => (
              <p><a href="#">{item.name} </a>({item.quantity}) <span class="CheckoutPrice">{item.price}</span></p>

            ))
            }
            <hr />
            <p>Total <span class="CheckoutPrice" style={{ color: "black" }}><b>${TotalPrice}</b></span></p>
          </div>
        </div>
      </div>
    </div>
  }
};
export default Checkout;