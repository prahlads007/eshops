import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { URL } from "../../utils/AppConstant";

function ProductList(props) {
    const [productList, setProductList] = useState([])
    const getProductList = async (isFilter) => {
        try {
            const response = await fetch(URL.product);
            const data = await response.json();
            setProductList(isFilter ? data.result.products.filter(x => x.type === props.productType) : data.result.products);
        } catch (e) {
            console.error(e);
        }
    }
    useEffect(() => {
        if (props.productType && props.productType > 0) {
            getProductList(true)
        } else {
            getProductList();
        }
    }, [props])

    return (<div>
        <section class="man-banner spad">
            <div class="container-fluid">
                <div class="row">
                    {productList.map(item => (
                        <div key={item.id} class="col-md-4">
                            <div class="product-item">
                                <div class="pi-pic">
                                    {ProductDisplay(item.type, item.type === 2 ? item.vedioUrl : item.imageUrl)}

                                    <div class="icon">
                                        <i class="icon_heart_alt"></i>
                                    </div>
                                    <ul>
                                        <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                        <Link class="quick-view" to={`/product/${item.id}`}>+ Quick View</Link>
                                        {/* <li class="quick-view"><a href="#">+ Quick View</a></li> */}
                                        <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                    </ul>
                                </div>
                                <div class="pi-text">
                                    <div class="catagory-name">Type: {item.type === 2 ? 'Vedio' : 'Book'} </div>
                                    <a href="#">
                                        <h5>{item.name}</h5>
                                    </a>
                                    <div class="product-price">
                                        ${item.price}
                                        <span>${item.originalPrice}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}

                    {/* <div class="col-lg-3 offset-lg-1">
                        <div class="product-large set-bg m-large" data-setbg="../../assets/img/man-large.jpg">
                            <h2>Men’s</h2>
                            <a href="#">Discover More</a>
                        </div>
                    </div>  */}
                </div>
            </div>
        </section>
    </div>
    );
};

function ProductDisplay(type, url) {
    if (type === 2) {

        return <iframe width="420" height="315"
            src={url}>
        </iframe>
    } else {

        return <img src={url} alt="" width="420" height="315" />
    }
}

export default ProductList;