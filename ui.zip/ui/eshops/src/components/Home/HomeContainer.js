import React from "react";
import Slider from './Slider'
import ProductList from './ProductList'

function HomeContainer() {
  return (<div>
    <Slider />
    <ProductList />
  </div>);
};

export default HomeContainer;