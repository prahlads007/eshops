import React, { useEffect, useState } from "react";
import { URL } from "../../utils/AppConstant";
import Layout from "../../pages/Layout"
import "./OrderDetails.css"

function OrderDetails() {
    const [OrderList, setOrderList] = useState(null)
    useEffect(() => {
        getOrderList();
    }, [])
    const getOrderList = async () => {
        try {
            const response = await fetch(URL.order);
            const data = await response.json();
            setOrderList(data.result.orderDetails);
        } catch (e) {
            console.log(e);
        }
    }

    return (OrderList &&
        <div>
            <h2>Order Details</h2>
            <table id="customers">
                <tr>
                    <th>Order Id</th>
                    <th>Product Id</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Payment Status</th>
                    <th>Address</th>
                </tr>
                {OrderList.map(item => (
                    <tr>
                        <td>{item.id}</td>
                        <td>{item.sku}</td>
                        <td>{item.amount}</td>
                        <td>{item.status}</td>
                        <td>{item.paymentStatus}</td>
                        <td>{item.shipAddress}</td>
                    </tr>
                ))}
            </table>
        </div>
    );
};

export default OrderDetails;