import React, { useEffect, useState } from "react";
import ProductList from '../Home/ProductList'

function ListContainer() {
  const [productType, setProductType] = useState(0)
  useEffect(() => {
    
  }, [productType])

  function FilterCallback(e) {
    setProductType(Number(e))
  }

  return (<div>
    <br /><div class="filters">
      Filters:
      <select name="filters" id="filters" onChange={e => FilterCallback(e.target.value)} >
        <option value='0'>All</option>
        <option value='1'>Only Books</option>
        <option value='2'>Only Videos</option>
      </select>
      <br />

    </div>
    <ProductList productType={productType} />
  </div>);
};




export default ListContainer;

