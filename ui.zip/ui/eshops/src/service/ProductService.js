import React from 'react';
import { URL } from '../utils/AppConstant';


export function getProductList(callback) {
  fetch(URL.product)
    .then(res => { callback(res.json()) })

}

      async getData(){
  var response = await fetch(URL.product)
  console.log(response);
}
