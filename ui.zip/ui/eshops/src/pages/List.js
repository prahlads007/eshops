import React from "react";
import ListContainer from '../components/List/ListContainer'

const List = () => {
    return (<ListContainer />);
  };
  
  export default List;