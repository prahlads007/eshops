import OrderDetails from '../components/Order/OrderDetails'
const Orders = () => {
    return <div>
      <OrderDetails />
      </div>;
  };
  
  export default Orders;