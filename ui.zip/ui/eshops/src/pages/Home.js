import HomeContainer from '../components/Home/HomeContainer'
const Home = () => {
    return <div>
      <HomeContainer />
      </div>;
  };
  
  export default Home;