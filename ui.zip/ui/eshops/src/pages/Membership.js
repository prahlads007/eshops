const Membership = () => {
    return <h1>Buy Membership</h1>;
  };
  
  export default Membership;