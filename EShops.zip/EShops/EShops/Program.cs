using EshopServices.Implementations;
using EshopServices.IServices;
using Serilog;
var builder = WebApplication.CreateBuilder(args);
builder.Host.UseSerilog();
builder.Logging.AddSerilog();

// Add services to the container.

builder.Services.AddControllers();

builder.Services.AddScoped<IProductDetails, ProductDetails>();
builder.Services.AddScoped<IOrderDetails, OrderDetails>();
builder.Services.AddScoped<ICartDetails, CartDetails>();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(p=>p.AddPolicy("corsapp", builder=>{
    builder.WithOrigins("*").AllowAnyMethod().AllowAnyHeader();
}));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseSerilogRequestLogging();
app.UseCors("corsapp");
app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
//builder.Host.UseSerilog((hostContext, services, configuration) => {
//    configuration.WriteTo.Console();
//});