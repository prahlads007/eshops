﻿using EshopDto.Models;
using EshopServices.IServices;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.IO;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EShops.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartDetails _cartService;

        public CartController(ICartDetails cartService)
        {
            _cartService= cartService;
        }
        // GET: api/<CartController>
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_cartService.GetAsync());
        }

        // GET api/<CartController>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            AddedItems result = await _cartService.GetByIdAsync(id);
            if (result== null)
            {
                return NotFound();
            }
            return Ok(result);
        }

        // POST api/<CartController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] AddToCart item)
        {
            return Ok(await _cartService.Add(item));
        }

        // PUT api/<CartController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<CartController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
