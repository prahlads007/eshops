﻿using EshopDto.Models;
using EshopServices.IServices;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.IO;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EShops.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly ILogger<OrderController> _logger;
        private readonly IOrderDetails _orderService;

        public OrderController(ILogger<OrderController> logger, IOrderDetails orderService)
        {
            _logger = logger;
            _orderService = orderService;   
        }
        // GET: api/<OrderController>
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                _logger.LogDebug("OrderController: Start Get order list");
                return Ok(_orderService.GetAsync());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "OrderController Get Method");
                return BadRequest();
            }
            finally {
                _logger.LogError("OrderController: End Get order list");
            }
        }

        // GET api/<OrderController>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            OrdersModel result =await _orderService.GetByIdAsync(id);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }

        // POST api/<OrderController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] OrdersModel OrderItem)
        {
            return Ok(await _orderService.Add(OrderItem));
        }

        // PUT api/<OrderController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<OrderController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
