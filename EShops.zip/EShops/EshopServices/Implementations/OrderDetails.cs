﻿using EshopDto.Models;
using EshopServices.IServices;
using Newtonsoft.Json;

namespace EshopServices.Implementations
{
    public class OrderDetails: IOrderDetails
    {
        public async Task<Orders> GetAsync() {
            using (StreamReader r = new StreamReader("Data/orderData.json"))
            {
                string json = r.ReadToEnd();
                Orders item = JsonConvert.DeserializeObject<Orders>(json);
                return await Task.FromResult(item);
            }
        }

        public async Task<OrdersModel> GetByIdAsync(int id)
        {
            using (StreamReader r = new StreamReader("Data/orderData.json"))
            {
                string json = r.ReadToEnd();
                Orders item = JsonConvert.DeserializeObject<Orders>(json);
                OrdersModel orderItems = item.orderDetails.Find(x => x.id == id);
                if (orderItems != null)
                {
                    return await Task.FromResult(orderItems);
                }
                return null;
            }

        }

        public async Task<bool> Add(OrdersModel OrderItem)
        {
            var filePath = "Data/orderData.json";
            Orders items = new Orders();
            using (StreamReader r = new StreamReader(filePath))
            {
                string json2 = r.ReadToEnd();
                items = JsonConvert.DeserializeObject<Orders>(json2);
                items.orderDetails.Add(OrderItem);
            }
            string jsonData = JsonConvert.SerializeObject(items, Formatting.Indented);
            System.IO.File.WriteAllText(filePath, jsonData);


            var cartList = "Data/cartData.json";
            AddedItems addedItems = new AddedItems();
            CartItems cartItems = new CartItems();
            using (StreamReader r2 = new StreamReader(filePath))
            {
                string json2 = r2.ReadToEnd();
                cartItems = JsonConvert.DeserializeObject<CartItems>(json2);
                cartItems.addedItems = new List<AddedItems>();
            }
            string cartData = JsonConvert.SerializeObject(cartItems, Formatting.Indented);
            System.IO.File.WriteAllText(cartList, cartData);
            return true;
        }
        }
}
