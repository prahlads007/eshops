﻿using EshopDto.Models;
using EshopServices.IServices;
using Newtonsoft.Json;

namespace EshopServices.Implementations
{
    public class ProductDetails: IProductDetails
    {
        public async Task<Products> GetAsync() {
            using (StreamReader r = new StreamReader("Data/productData.json"))
            {
                string json = r.ReadToEnd();
                Products item = JsonConvert.DeserializeObject<Products>(json);
                return await Task.FromResult(item);
            }
        }

        public async Task<ProductModel> GetByIdAsync(int id)
        {
            using (StreamReader r = new StreamReader("Data/productData.json"))
            {
                string json = r.ReadToEnd();
                Products item = JsonConvert.DeserializeObject<Products>(json);
                ProductModel product = item.products.Find(x => x.id == id);
                if (product != null)
                {
                    return await Task.FromResult(product);
                }
                return null;
            }

        }
    }
}
