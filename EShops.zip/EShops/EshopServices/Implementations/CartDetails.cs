﻿using EshopDto.Models;
using EshopServices.IServices;
using Newtonsoft.Json;

namespace EshopServices.Implementations
{
    public class CartDetails: ICartDetails
    {
        public async Task<CartItems> GetAsync() {
            using (StreamReader r = new StreamReader("Data/cartData.json"))
            {
                string json = r.ReadToEnd();
                CartItems item = JsonConvert.DeserializeObject<CartItems>(json);
                return await Task.FromResult(item);
            }
        }

        public async Task<AddedItems> GetByIdAsync(int id)
        {
            using (StreamReader r = new StreamReader("Data/cartData.json"))
            {
                string json = r.ReadToEnd();
                CartItems item = JsonConvert.DeserializeObject<CartItems>(json);
                AddedItems addedItems = item.addedItems.Find(x => x.id == id);
                if (addedItems != null)
                {
                    return await Task.FromResult(addedItems);
                }
                return null;
            }

        }

        public async Task<bool> Add(AddToCart addtoCartItem)
        {
            try
            {
                var filePath = "Data/cartData.json";
                AddedItems addedItems = new AddedItems();
                using (StreamReader r = new StreamReader("Data/productData.json"))
                {
                    string json = r.ReadToEnd();
                    Products item = JsonConvert.DeserializeObject<Products>(json);
                    ProductModel product = item.products.Find(x => x.id == addtoCartItem.id);
                    addedItems.id = product.id;
                    addedItems.name = product.name;
                    addedItems.price = product.price;
                    addedItems.quantity = 1;
                }
                CartItems items = new CartItems();
                using (StreamReader r2 = new StreamReader(filePath))
                {
                    string json2 = r2.ReadToEnd();
                    items = JsonConvert.DeserializeObject<CartItems>(json2);
                    items.addedItems.Add(addedItems);
                }
                string jsonData = JsonConvert.SerializeObject(items, Formatting.Indented);
                System.IO.File.WriteAllText(filePath, jsonData);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }



    }
}
