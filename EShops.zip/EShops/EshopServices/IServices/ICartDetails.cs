﻿using EshopDto.Models;

namespace EshopServices.IServices
{
    public interface ICartDetails
    {
        Task<CartItems> GetAsync();
        Task<AddedItems> GetByIdAsync(int id);
        Task<bool> Add(AddToCart addtoCartItem);
    }
}
