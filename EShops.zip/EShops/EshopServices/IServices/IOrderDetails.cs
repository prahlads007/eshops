﻿using EshopDto.Models;

namespace EshopServices.IServices
{
    public interface IOrderDetails
    {
        Task<Orders> GetAsync();
        Task<OrdersModel> GetByIdAsync(int id);
        Task<bool> Add(OrdersModel OrderItem);
    }
}
