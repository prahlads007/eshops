﻿using EshopDto.Models;

namespace EshopServices.IServices
{
    public interface IProductDetails
    {
        Task<Products> GetAsync();
        Task<ProductModel> GetByIdAsync(int id);
    }
}
