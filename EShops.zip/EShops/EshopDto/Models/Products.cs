﻿namespace EshopDto.Models
{
    public class Products
    {
        public List<ProductModel> products { get; set; }
    }
    public class ProductModel
    {
        public int id { get; set; }
        public int type { get; set; }
        public int price { get; set; }
        public int originalPrice { get; set; }
        public int membership { get; set; }
        public string name { get; set; }
        public string imageUrl { get; set; }
        public string vedioUrl { get; set; }
        public string description { get; set; }


    }

}
