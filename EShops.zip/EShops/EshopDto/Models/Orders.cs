﻿namespace EshopDto.Models
{
    public class Orders
    {
        public List<OrdersModel> orderDetails { get; set; }
    }
    public class OrdersModel
    {
        public int id { get; set; }
        public string sku { get; set; }
        public int amount { get; set; }
        public string productName { get; set; }
        public string username { get; set; }
        public string billAddress { get; set; }
        public string shipAddress { get; set; }
        public string status { get; set; }
        public string paymentStatus { get; set; }
    }
}
