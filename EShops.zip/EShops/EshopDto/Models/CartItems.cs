﻿namespace EshopDto.Models
{
    public class CartItems
    {
        public List<AddedItems> addedItems { get; set; }
    }
    public class AddedItems
    {
        public int id { get; set; }
        public string name { get; set; }
        public int price { get; set; }
        public int quantity { get; set; }
    }

     public class AddToCart
    {
        public int id { get; set; }
        }

}
